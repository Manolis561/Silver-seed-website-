SILVER SEED WEBSITE — VERSION 2
This version uses the five supplied Silver Seed brand/concept images.

To preview:
• Open index.html in a browser.
• Keep the assets folder beside index.html.

Before public launch:
• Replace the concept/gallery images with approved photographs of actual finished Silver Seed work where desired.
• Confirm the final legal/trademark wording and domain.
• Replace the placeholder enquiry email.
• Add privacy/cookie information and a real contact form.
• Keep proprietary formulations and process parameters off the public site.
